'use strict';
require('dotenv').config();
const {connectMongo,mongoose}=require('../src/mongo');
const {Project,Skill,Service,SiteSettings}=require('../src/models');
const projects=[
{title:'JobPulseIndia',slug:'jobpulseindia',category:'frontend',description:'Independent job information portal design for organizing recruitment news, results and admit cards. Not an official government website.',status:'in-progress',technologies:['HTML','CSS','JavaScript'],sortOrder:1,featured:true},
{title:'Aurelis School',slug:'aurelis-school',category:'frontend',description:'An educational website design with admissions information, responsive sections and accessible navigation.',status:'in-progress',technologies:['HTML','CSS','JavaScript'],sortOrder:2,featured:true},
{title:'Nexora CRM',slug:'nexora-crm',category:'concept',description:'CRM product concept exploring customer records, lead tracking, workflows and sales dashboard designs. Not a deployed production CRM.',status:'concept',technologies:['UI Design','Node.js','MongoDB'],sortOrder:3,featured:true},
{title:'FreeNova',slug:'freenova',category:'concept',description:'Concept for an independent freelance marketplace with portfolio discovery and elegant talent profiles.',status:'concept',technologies:['UI/UX','Product Design'],sortOrder:4,featured:true}
];
const skills=[['HTML5','frontend'],['CSS3','frontend'],['JavaScript','frontend'],['React','frontend'],['Node.js','backend'],['Express.js','backend'],['REST APIs','backend'],['MongoDB','database'],['PostgreSQL','database'],['Git','tools'],['GitHub','tools'],['VS Code','tools'],['Figma','tools']].map(([name,category],i)=>({name,category,icon:'✳',sortOrder:i}));
const services=[['Responsive Website Development','Mobile-friendly websites designed for every screen size.'],['Frontend Development','Clean, accessible and interactive interfaces.'],['Backend and API Development','Server routes, validation and API integrations.'],['Full-Stack Web Applications','Connecting user interfaces, server logic and data.'],['Landing Page Design','Conversion-focused and fast-loading landing pages.'],['UI Design','Thoughtful typography, hierarchy and interaction.']].map(([title,description],i)=>({title,description,icon:['◈','✳','⌘','◇','↗','✦'][i],sortOrder:i}));
async function main(){await connectMongo(process.env.MONGODB_URI);
for(const p of projects)await Project.updateOne({slug:p.slug},{$setOnInsert:p},{upsert:true});
for(const s of skills)await Skill.updateOne({name:s.name},{$setOnInsert:s},{upsert:true});
for(const s of services)await Service.updateOne({title:s.title},{$setOnInsert:s},{upsert:true});
await SiteSettings.updateOne({key:'main'},{$setOnInsert:{key:'main'}},{upsert:true});console.log('Sample portfolio records created if missing; existing data preserved.');}
main().catch(e=>{console.error('Seed error:',e.message);process.exitCode=1}).finally(()=>mongoose.disconnect());
