'use strict';
require('dotenv').config();
const bcrypt=require('bcryptjs');
const {connectMongo,mongoose}=require('../src/mongo');
const {Admin}=require('../src/models');
async function main(){const email=process.env.ADMIN_EMAIL?.trim().toLowerCase(),password=process.env.ADMIN_PASSWORD;
if(!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || !password || password.length<12 || /REPLACE|YOUR_/i.test(password))throw new Error('Set a valid ADMIN_EMAIL and strong ADMIN_PASSWORD (12+ characters) in your private .env');
await connectMongo(process.env.MONGODB_URI);const existing=await Admin.findOne({email});if(existing){console.log('Admin already exists; no password changed.');return;}
const count=await Admin.countDocuments();if(count)throw new Error('An admin account already exists. The setup script refuses to create a second admin.');
await Admin.create({email,passwordHash:await bcrypt.hash(password,12),role:'owner'});console.log('Admin account created. Remove ADMIN_PASSWORD from your deployment environment after setup.');}
main().catch(e=>{console.error('Setup error:',e.message);process.exitCode=1}).finally(()=>mongoose.disconnect());
