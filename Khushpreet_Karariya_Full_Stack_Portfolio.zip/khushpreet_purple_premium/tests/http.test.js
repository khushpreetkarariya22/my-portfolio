'use strict';
const {test}=require('node:test');const assert=require('node:assert/strict');const request=require('supertest');const {createApp}=require('../src/app');
const app=createApp({NODE_ENV:'test',SESSION_SECRET:'test-only-secret-98765432109876543210987654321'});
test('frontend loads without requiring a database for visual preview',async()=>{const res=await request(app).get('/');assert.equal(res.status,200);assert.match(res.text,/KHUSHPREET/)});
test('admin dashboard requires authentication',async()=>{const res=await request(app).get('/admin/dashboard.html');assert.equal(res.status,401)});
test('unauthenticated administrative APIs reject callers',async()=>{const res=await request(app).get('/api/admin/projects');assert.equal(res.status,401)});
test('real database endpoints return 503 when MongoDB is unconfigured (never fake success)',async()=>{const res=await request(app).get('/api/projects');assert.equal(res.status,503)});
test('CSRF origin checks reject cross-origin submissions',async()=>{const res=await request(app).post('/api/contact').set('Origin','https://attacker.example').send({});assert.equal(res.status,403)});
test('API uses security headers',async()=>{const res=await request(app).get('/api/health');assert.equal(res.status,200);assert.ok(res.headers['x-content-type-options']);assert.ok(res.headers['content-security-policy'])});
