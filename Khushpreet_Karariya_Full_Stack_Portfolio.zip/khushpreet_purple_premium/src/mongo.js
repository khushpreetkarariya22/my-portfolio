'use strict';
const mongoose=require('mongoose');
async function connectMongo(uri){if(!uri || /YOUR_|YOUR_CLUSTER/.test(uri)) throw new Error('Configure a genuine MONGODB_URI in .env');await mongoose.connect(uri,{serverSelectionTimeoutMS:10000,maxPoolSize:10});return mongoose.connection;}
module.exports={mongoose,connectMongo};
