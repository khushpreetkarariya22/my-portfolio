'use strict';
const {mongoose} = require('./mongo');
const options={timestamps:true,strict:'throw'};
const Admin=mongoose.model('Admin',new mongoose.Schema({email:{type:String,required:true,unique:true,lowercase:true,trim:true},passwordHash:{type:String,required:true,select:false},role:{type:String,enum:['owner'],default:'owner'}},options));
const Project=mongoose.model('Project',new mongoose.Schema({
 title:{type:String,required:true,maxlength:120,trim:true},slug:{type:String,required:true,unique:true,lowercase:true,trim:true},
 category:{type:String,enum:['frontend','concept','fullstack','design'],required:true},description:{type:String,required:true,maxlength:3000},
 coverImage:{type:String,default:''},gallery:{type:[String],default:[]},technologies:{type:[String],default:[]},
 status:{type:String,enum:['completed','in-progress','concept'],required:true,default:'concept'},
 githubUrl:{type:String,default:''},liveUrl:{type:String,default:''},featured:{type:Boolean,default:false},sortOrder:{type:Number,default:0}
},options));
Project.schema.index({sortOrder:1,createdAt:-1});
const Skill=mongoose.model('Skill',new mongoose.Schema({name:{type:String,required:true,maxlength:80},category:{type:String,enum:['frontend','backend','database','tools'],required:true},icon:{type:String,default:'✳'},proficiency:{type:Number,min:0,max:100,default:null},sortOrder:{type:Number,default:0}},options));
Skill.schema.index({sortOrder:1});
const Service=mongoose.model('Service',new mongoose.Schema({title:{type:String,required:true,maxlength:100},description:{type:String,required:true,maxlength:500},icon:{type:String,default:'✳'},active:{type:Boolean,default:true},sortOrder:{type:Number,default:0}},options));
Service.schema.index({sortOrder:1});
const ContactMessage=mongoose.model('ContactMessage',new mongoose.Schema({name:{type:String,required:true,maxlength:100},email:{type:String,required:true,maxlength:180},subject:{type:String,required:true,maxlength:150},projectType:{type:String,required:true,maxlength:100},budgetRange:{type:String,default:'',maxlength:100},message:{type:String,required:true,maxlength:3000},isRead:{type:Boolean,default:false}},options));
ContactMessage.schema.index({createdAt:-1});ContactMessage.schema.index({isRead:1,createdAt:-1});
const SiteSettings=mongoose.model('SiteSettings',new mongoose.Schema({key:{type:String,unique:true,default:'main'},heroTitle:{type:String,default:"Designing Digital Experiences. Building What's Next."},heroSubtitle:{type:String,default:"Hi, I'm Khushpreet Karariya — a web developer and creative designer building beautiful, functional and engaging digital experiences."},aboutContent:{type:String,default:"I'm Khushpreet Karariya, a BCA student and aspiring full-stack developer based in Haryana, India. I enjoy transforming ideas into polished, responsive websites."},contactInformation:{email:{type:String,default:''},location:{type:String,default:'Haryana, India'}},socialLinks:{github:{type:String,default:''},linkedin:{type:String,default:''},instagram:{type:String,default:''}},cvUrl:{type:String,default:''},timeline:{type:[{year:{type:String,maxlength:12},title:{type:String,maxlength:120}}],default:[{year:'2025',title:'Started my BCA journey'},{year:'2026',title:'Developing personal web projects and product concepts'}]},seoMetadata:{title:{type:String,default:'Khushpreet Karariya — Developer & Designer'},description:{type:String,default:'Personal portfolio of Khushpreet Karariya, web developer and creative UI designer.'}}},options));
module.exports={Admin,Project,Skill,Service,ContactMessage,SiteSettings};
